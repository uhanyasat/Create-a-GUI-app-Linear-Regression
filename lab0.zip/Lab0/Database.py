def DatabaseFun(co2_year, co2_interpolated, temperature_year, temperature_median):

    #Aggregating of co2 data:
    co2_year_unique = []
    for i in co2_year:
        if i not in co2_year_unique:
            co2_year_unique.append(i)

    co2_interpolated_by_years = []
    for i in range(0, len(co2_year_unique)):
        fict = []
        for j in range(0, len(co2_year)):
            if co2_year[j] == co2_year_unique[i]:
                fict.append(co2_interpolated[j])
        co2_interpolated_by_years.append(fict)

    co2_interpolated_average = []
    for i in co2_interpolated_by_years:
        co2_interpolated_average.append(sum(i) / len(i))

    #Detection of limits of analyzed period:
    year_lowest = max( min(co2_year_unique), min(temperature_year) )
    year_highest = min( max(co2_year_unique), max(temperature_year) )

    #Creation of final year list:
    year = list(range(year_lowest, year_highest + 1))

    #Creation of final co2 list:
    co2_list = []
    for i in range(0, len(co2_year_unique)):
        if (co2_year_unique[i] >= year_lowest) and (co2_year_unique[i] <= year_highest):
            co2_list.append(co2_interpolated_average[i])

    #Creation of final temp list:
    temp_list = []
    for i in range(0, len(temperature_year)):
        if (temperature_year[i] >= year_lowest) and (temperature_year[i] <= year_highest):
            temp_list.append(temperature_median[i])

    #Creation of database:

    temp = {}
    co2 = {}
    for i in range(0, len(year)):
        temp.update({year[i]:temp_list[i]})
        co2.update({year[i]:co2_list[i]})
    database = [temp, co2]

    return database
