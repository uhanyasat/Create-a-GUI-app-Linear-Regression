#Libraries used:
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from DataReader import *
from DataParser import *
from Database import *

#Start of main program:
if __name__ == '__main__': 
    

#Using of classes:
    co2_file = DataReader("Co2.html").ReadFun()
    temperature_file = DataReader("Temperature.html").ReadFun()    
    co2_year_input = Parser(co2_file, 0, 4, 4).ParsingFun()[0]
    co2_interpolated_input = Parser(co2_file, 0, 4, 4).ParsingFun()[1]
    temperature_year_input = Parser(temperature_file, 0, 1, 5).ParsingFun()[0]
    temperature_median_input = Parser(temperature_file, 0, 1, 5).ParsingFun()[1]

#Creation of database:
    database = DatabaseFun(co2_year_input, co2_interpolated_input, temperature_year_input, temperature_median_input)    

#Plotting:
    plt.bar(database[0].keys(), [i if i < 0 else 0 for i in database[0].values()], color = "blue")
    plt.ylabel("Deviation of average temperature (Celcius)")
    plt.xlabel("Year")
    plt.title("Global Temperature and Carbon Dioxide")
    plt.bar(database[1].keys(), [i if i > 0 else 0 for i in database[0].values()], color = "red")
    plt.twinx()
    plt.plot(database[1].keys(), database[1].values(), color = "black")
    plt.ylabel("CO2 Concentration (ppm)")
    plt.show()

#Defining of slope function:
    def SlopeFun(Y, X):
        n = len(Y)
        fict_1 = []
        for i in range(0, n):
            fict_1.append( ( (sum(X) / len(X)) - X[i]) ** 2)
        ssxx = sum(fict_1)
        fict_2 = []
        for i in range(0, n):
            fict_2.append( ( (sum(X) / len(X)) - X[i]) * ( (sum(Y) / len(Y)) - Y[i]))
        ssxy = sum(fict_2)
        slope = ssxy / ssxx
        return slope

#Creation of regression model by sklearn:
    model = LinearRegression().fit([[i] for i in database[1].values()], list(database[0].values()))

#Test of slope function:
    print("Slope:")
    print(SlopeFun(list(database[0].values()), list(database[1].values())))
    print(model.coef_[0])













