class Parser:
    def __init__(self, raw_data, year_column, values_column, start_of_data):
        self.raw_data = raw_data
        self.year_column = year_column
        self.values_column = values_column
        self.start_of_data = start_of_data        
    def ParsingFun(self):
        parsed_data = self.raw_data[self.start_of_data:len(self.raw_data)-1]
        parsed_data = [i.replace('  <TBODY><TR><TD>', '') for i in parsed_data]
        parsed_data = [i.replace('</TD></TR></TBODY>\n', '') for i in parsed_data]
        parsed_year = []
        parsed_values = []
        for i in parsed_data:
            parsed_year.append(int(i.split("</TD><TD>")[self.year_column]))
            parsed_values.append(float(i.split("</TD><TD>")[self.values_column]))
        return parsed_year, parsed_values 
