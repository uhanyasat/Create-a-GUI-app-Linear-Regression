class DataReader:
    def __init__(self, file):
        self.file = file
    def ReadFun(self):
        raw_data = open(self.file, "r").readlines()
        return raw_data
